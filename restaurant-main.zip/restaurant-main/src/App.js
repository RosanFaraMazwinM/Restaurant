import {useState, useEffect} from 'react'
import {IoCartOutline} from 'react-icons/io5'
import './App.css'

const App = () => {
  const [restaurantData, setRestaurantData] = useState([])
  const [selectedCategory, setSelectedCategory] = useState(0)
  const selectedMenu = restaurantData[0]?.table_menu_list?.[selectedCategory]
  const [cartItems, setCartItems] = useState({})

  useEffect(() => {
    fetch('https://apis2.ccbp.in/restaurant-app/restaurant-menu-list-details')
      .then(response => response.json())
      .then(data => {
        setRestaurantData(data)

        const quantities = {}

        data[0].table_menu_list.forEach(category => {
          category.category_dishes.forEach(dish => {
            quantities[dish.dish_id] = 0
          })
        })

        setCartItems(quantities)
      })
  }, [])

  const increaseCount = dishId => {
    setCartItems(prev => ({
      ...prev,
      [dishId]: (prev[dishId] || 0) + 1,
    }))
  }

  const decreaseCount = dishId => {
    setCartItems(prev => {
      const currentCount = prev[dishId] || 0

      if (currentCount === 0) {
        return prev
      }

      return {
        ...prev,
        [dishId]: currentCount - 1,
      }
    })
  }

  const totalCartItems = Object.values(cartItems).reduce(
    (total, count) => total + count,
    0,
  )

  return (
    <div className="container">
      <div className="nav-container">
        <h1 className="brand">{restaurantData[0]?.restaurant_name}</h1>
        <div className="order-container">
          <h1 className="ord">My Orders</h1>
          <p className="icon">
            <IoCartOutline />
          </p>
          <p className="count">{totalCartItems}</p>
        </div>
      </div>
      <div className="menu-container">
        {restaurantData[0]?.table_menu_list.map((category, index) => (
          <button
            type="button"
            className={selectedCategory === index ? 'btn-active' : 'btn'}
            key={category.menu_category_id}
            onClick={() => setSelectedCategory(index)}
          >
            {category.menu_category}
          </button>
        ))}
      </div>

      <div className="card-container">
        {selectedMenu?.category_dishes.map(dish => (
          <div className="card" key={dish.dish_id}>
            <div className="text">
              <h2>
                {dish.dish_Type === 2 ? (
                  <span className="veg-icon">●</span>
                ) : (
                  <span className="nonveg-icon">●</span>
                )}
                {dish.dish_name}
              </h2>
              <p className="cost">
                {dish.dish_currency} {dish.dish_price}
              </p>

              <p className="desc">{dish.dish_description}</p>

              {dish.dish_Availability ? (
                <div className="button-container">
                  <button
                    type="button"
                    className="dec"
                    onClick={() => decreaseCount(dish.dish_id)}
                  >
                    -
                  </button>

                  <p className="num">{cartItems[dish.dish_id] || 0}</p>

                  <button
                    type="button"
                    className="inc"
                    onClick={() => increaseCount(dish.dish_id)}
                  >
                    +
                  </button>
                </div>
              ) : (
                <p className="para">Not Available</p>
              )}

              {dish.addonCat?.length > 0 && (
                <p className="available">Customizations available</p>
              )}
            </div>
            <div className="calories">
              <p className="counting">{dish.dish_calories} calories</p>
            </div>
            <div className="img-container">
              <img src={dish.dish_image} alt={dish.dish_name} width="150" />
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

export default App
